<?php
class BI_Model extends CI_Model{
    public function index(){
        
    }
}
?>