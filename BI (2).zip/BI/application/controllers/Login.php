<?php
class Login extends CI_controller{
    
    public function index() {
        $this->load->view('login');
    }
}