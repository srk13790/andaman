<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
            <img src="<?php echo base_url();?>assets/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Admin</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
<!--      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>-->
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>
        <li id="nav-dashboard"><a href="dashboard"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
        <li id="nav-trip_planner"><a href="trip_planner"><i class="fa fa-map"></i> <span>Trip Planner</span></a></li>
        <li id="nav-rewards"><a href="rewards"><i class="fa fa-gift"></i> <span>Rewards</span></a></li>
        <li class="treeview" id="nav-events">
          <a href="#">
            <i class="fa fa-television"></i> <span>Events</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li id="nav-events"><a href="events"><i class="fa fa-circle-o"></i> Events</a></li>
            <li><a href="mice"><i class="fa fa-circle-o"></i> Mice</a></li>
            <li><a href="destination_wedding"><i class="fa fa-circle-o"></i> Destination Wedding</a></li>
            <li><a href="eco_tour"><i class="fa fa-circle-o"></i> Eco Tour</a></li>
          </ul>
        </li>
        
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>